#pragma once
#include <windows.h>
#include <string>

class DllHook {
public:
    // Uses WCHAR* to match the Wide strings from the UI
    static DWORD GetProcessId(const WCHAR* processName, std::wstring& errMsg);
    
    // Core injection logic
    static bool LoadLib(DWORD dwProcessId, LPWSTR szDllPath);
    
    // Optional: for unloading the DLL later
    static bool FreeLib(DWORD dwProcessId, const WCHAR* szDllPath);
    
    // Helper for showing errors in a popup
    static void ShowError(DWORD dwErr, const WCHAR* msg);
};