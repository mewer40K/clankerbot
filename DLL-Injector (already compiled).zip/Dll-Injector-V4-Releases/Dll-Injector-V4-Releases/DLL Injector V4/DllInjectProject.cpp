﻿#include <windows.h>
#include <commdlg.h>
#include <CommCtrl.h>
#include <tlhelp32.h>
#include <string>
#include <vector>
#include "DllHook.h"

// UI Constants
#define IDM_BUTTON_INJECT 101
#define IDM_BUTTON_UNLOAD 102
#define IDM_BUTTON_REFRESH 103
#define IDM_EDIT_PROCESS 104
#define IDM_LISTVIEW 105
#define IDM_BUTTON_BROWSE 106
#define IDM_EDIT_DLL 107

// Forward Declarations
ATOM MyRegisterClass(HINSTANCE hInstance);
BOOL InitInstance(HINSTANCE, int);
LRESULT CALLBACK WndProc(HWND, UINT, WPARAM, LPARAM);
void ButtonInjectClick(HWND hWnd);
void RefreshProcessList(HWND hWnd);
void BrowseForDLL(HWND hWnd);
BOOL InitListViewColumns(HWND hWndListView);
bool SetPrivilege();

// Global Variables
HINSTANCE hInst;
HWND hListView;
WCHAR szTitle[] = L"Process Picker & DLL Injector";
WCHAR szWindowClass[] = L"CE_STYLE_INJECTOR";
    
void RefreshProcessList(HWND hWnd);
BOOL InitListViewColumns(HWND hWndListView);
bool SetPrivilege();

int APIENTRY wWinMain(_In_ HINSTANCE hInstance, _In_opt_ HINSTANCE hPrevInstance, _In_ LPWSTR lpCmdLine, _In_ int nCmdShow)
{
    SetPrivilege(); // Try to get Debug rights
    MyRegisterClass(hInstance);
    if (!InitInstance(hInstance, nCmdShow)) return FALSE;

    MSG msg;
    while (GetMessage(&msg, nullptr, 0, 0))
    {
        TranslateMessage(&msg);
        DispatchMessage(&msg);
    }
    return (int)msg.wParam;
}

ATOM MyRegisterClass(HINSTANCE hInstance)
{
    WNDCLASSEXW wcex = { sizeof(WNDCLASSEXW) };
    wcex.style = CS_HREDRAW | CS_VREDRAW;
    wcex.lpfnWndProc = WndProc;
    wcex.hInstance = hInstance;
    wcex.hIcon = LoadIcon(NULL, IDI_APPLICATION);
    wcex.hCursor = LoadCursor(nullptr, IDC_ARROW);
    wcex.hbrBackground = (HBRUSH)(COLOR_WINDOW + 1);
    wcex.lpszClassName = szWindowClass;
    return RegisterClassExW(&wcex);
}

BOOL InitInstance(HINSTANCE hInstance, int nCmdShow)
{
    hInst = hInstance;
    HWND hWnd = CreateWindowW(szWindowClass, szTitle, WS_OVERLAPPEDWINDOW ^ WS_THICKFRAME,
                              CW_USEDEFAULT, 0, 600, 550, nullptr, nullptr, hInstance, nullptr);

    if (!hWnd) return FALSE;
    ShowWindow(hWnd, nCmdShow);
    UpdateWindow(hWnd);
    return TRUE;
}

LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
    switch (message)
    {
    case WM_CREATE:
        {
            RECT rc;
            GetClientRect(hWnd, &rc);
            
            // 1. Setup Cheat Engine Style List
            hListView = CreateWindowW(WC_LISTVIEWW, L"", WS_CHILD | WS_VISIBLE | WS_BORDER | LVS_REPORT,
                                     10, 10, rc.right - 20, rc.bottom - 100, hWnd, (HMENU)IDM_LISTVIEW, hInst, nullptr);
            InitListViewColumns(hListView);

            // 2. Setup Controls (Positioned at the bottom)
            int bY = rc.bottom - 80;
            // Row 1: Inject and Process Name
            CreateWindowW(L"BUTTON", L"Inject DLL", WS_VISIBLE | WS_CHILD | BS_DEFPUSHBUTTON, 10, bY, 110, 35, hWnd, (HMENU)IDM_BUTTON_INJECT, hInst, nullptr);
            CreateWindowW(L"EDIT", L"notepad.exe", WS_VISIBLE | WS_CHILD | WS_BORDER | ES_LEFT | ES_AUTOHSCROLL, 130, bY + 5, 120, 25, hWnd, (HMENU)IDM_EDIT_PROCESS, hInst, nullptr);
            
            // Row 2: DLL Path and Browse
            CreateWindowW(L"EDIT", L"C:\\Users\\Public\\Ldll.dll", WS_VISIBLE | WS_CHILD | WS_BORDER | ES_LEFT | ES_AUTOHSCROLL, 260, bY + 5, 150, 25, hWnd, (HMENU)IDM_EDIT_DLL, hInst, nullptr);
            CreateWindowW(L"BUTTON", L"Browse...", WS_VISIBLE | WS_CHILD, 420, bY, 80, 35, hWnd, (HMENU)IDM_BUTTON_BROWSE, hInst, nullptr);
            
            // Refresh Button
            CreateWindowW(L"BUTTON", L"Refresh", WS_VISIBLE | WS_CHILD, 510, bY, 70, 35, hWnd, (HMENU)IDM_BUTTON_REFRESH, hInst, nullptr);

            RefreshProcessList(hWnd); 
            break;
        }
    case WM_COMMAND:
        switch (LOWORD(wParam))
        {
            case IDM_BUTTON_BROWSE: BrowseForDLL(hWnd); break; // New
            case IDM_BUTTON_INJECT: ButtonInjectClick(hWnd); break;
            case IDM_BUTTON_REFRESH: RefreshProcessList(hWnd); break;
        }
        break;
    case WM_NOTIFY:
        {
            // Detect Double-Click to select process
            LPNMHDR lpnmhdr = (LPNMHDR)lParam;
            if (lpnmhdr->idFrom == IDM_LISTVIEW && lpnmhdr->code == NM_DBLCLK)
            {
                LPNMITEMACTIVATE lpnmia = (LPNMITEMACTIVATE)lParam;
                WCHAR szName[MAX_PATH];
                ListView_GetItemText(hListView, lpnmia->iItem, 1, szName, MAX_PATH);
                SetWindowTextW(GetDlgItem(hWnd, IDM_EDIT_PROCESS), szName);
            }
            break;
        }
    case WM_DESTROY: PostQuitMessage(0); break;
    default: return DefWindowProcW(hWnd, message, wParam, lParam);
    }
    return 0;
}

// Opens File Explorer to pick a DLL
void BrowseForDLL(HWND hWnd) {
    OPENFILENAMEW ofn;
    WCHAR szFile[MAX_PATH] = { 0 };
    ZeroMemory(&ofn, sizeof(ofn));
    ofn.lStructSize = sizeof(ofn);
    ofn.hwndOwner = hWnd;
    ofn.lpstrFile = szFile;
    ofn.nMaxFile = sizeof(szFile);
    ofn.lpstrFilter = L"DLL Files (*.dll)\0*.dll\0All Files (*.*)\0*.*\0";
    ofn.Flags = OFN_PATHMUSTEXIST | OFN_FILEMUSTEXIST;

    if (GetOpenFileNameW(&ofn) == TRUE) {
        SetWindowTextW(GetDlgItem(hWnd, IDM_EDIT_DLL), ofn.lpstrFile);
    }
}

// Checks if process is an "App"
bool HasVisibleWindow(DWORD dwProcessId) {
    struct EnumData { DWORD dwProcessId; bool hasWindow; };
    EnumData data = { dwProcessId, false };
    EnumWindows([](HWND hwnd, LPARAM lParam) -> BOOL {
        EnumData* pData = (EnumData*)lParam;
        DWORD dwWinProcId;
        GetWindowThreadProcessId(hwnd, &dwWinProcId);
        if (pData->dwProcessId == dwWinProcId && IsWindowVisible(hwnd) && GetWindow(hwnd, GW_OWNER) == NULL) {
            pData->hasWindow = true; return FALSE;
        }
        return TRUE;
    }, (LPARAM)&data);
    return data.hasWindow;
}

void RefreshProcessList(HWND hWnd) {
    ListView_DeleteAllItems(hListView);
    HANDLE hSnapshot = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
    if (hSnapshot == INVALID_HANDLE_VALUE) return;

    PROCESSENTRY32W pe32;
    pe32.dwSize = sizeof(PROCESSENTRY32W);
    if (Process32FirstW(hSnapshot, &pe32)) {
        int appIndex = 0;
        do {
            bool isApp = HasVisibleWindow(pe32.th32ProcessID);
            LVITEMW item = { 0 };
            item.mask = LVIF_TEXT;
            item.iItem = isApp ? appIndex++ : ListView_GetItemCount(hListView);

            WCHAR pidStr[16];
            swprintf_s(pidStr, L"%08X", pe32.th32ProcessID);
            item.pszText = pidStr;
            int pos = ListView_InsertItem(hListView, &item);
            ListView_SetItemText(hListView, pos, 1, pe32.szExeFile);
            ListView_SetItemText(hListView, pos, 2, isApp ? (LPWSTR)L"App" : (LPWSTR)L"Background Process");
        } while (Process32NextW(hSnapshot, &pe32));
    }
    CloseHandle(hSnapshot);
}

void ButtonInjectClick(HWND hWnd) {
    WCHAR procName[MAX_PATH];
    WCHAR dllPath[MAX_PATH];
    
    GetWindowTextW(GetDlgItem(hWnd, IDM_EDIT_PROCESS), procName, MAX_PATH);
    GetWindowTextW(GetDlgItem(hWnd, IDM_EDIT_DLL), dllPath, MAX_PATH);
    
    std::wstring err = L"";
    DWORD pid = DllHook::GetProcessId(procName, err);
    
    if (pid != 0) {
        if (DllHook::LoadLib(pid, dllPath)) {
            MessageBoxW(hWnd, L"Injected Successfully!", L"Success", MB_OK);
        } else {
            MessageBoxW(hWnd, L"Injection Failed!", L"Error", MB_OK | MB_ICONERROR);
        }
    } else {
        MessageBoxW(hWnd, L"Target process not found.", L"Error", MB_OK | MB_ICONERROR);
    }
}

BOOL InitListViewColumns(HWND hWnd) {
    ListView_SetExtendedListViewStyle(hWnd, LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES | LVS_EX_DOUBLEBUFFER);
    LVCOLUMNW col = { 0 };
    col.mask = LVCF_TEXT | LVCF_WIDTH;
    col.pszText = (LPWSTR)L"PID"; col.cx = 80; ListView_InsertColumn(hWnd, 0, &col);
    col.pszText = (LPWSTR)L"Name"; col.cx = 200; ListView_InsertColumn(hWnd, 1, &col);
    col.pszText = (LPWSTR)L"Type"; col.cx = 150; ListView_InsertColumn(hWnd, 2, &col);
    return TRUE;
}

bool SetPrivilege() {
    HANDLE hToken; LUID luid; TOKEN_PRIVILEGES tp;
    if (!OpenProcessToken(GetCurrentProcess(), TOKEN_ADJUST_PRIVILEGES, &hToken)) return false;
    LookupPrivilegeValueW(NULL, SE_DEBUG_NAME, &luid);
    tp.PrivilegeCount = 1; tp.Privileges[0].Luid = luid; tp.Privileges[0].Attributes = SE_PRIVILEGE_ENABLED;
    AdjustTokenPrivileges(hToken, FALSE, &tp, sizeof(tp), NULL, NULL);
    return true;
}