#include "DllHook.h"
#include <tlhelp32.h>
#include <vector>

// Searches for a process by name and returns its PID
DWORD DllHook::GetProcessId(const WCHAR* processName, std::wstring& errMsg) {
    DWORD dwProcessId = 0;
    HANDLE hSnap = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);

    if (hSnap != INVALID_HANDLE_VALUE) {
        PROCESSENTRY32W pe32;
        pe32.dwSize = sizeof(PROCESSENTRY32W);

        if (Process32FirstW(hSnap, &pe32)) {
            do {
                // Case-insensitive comparison of wide strings
                if (_wcsicmp(pe32.szExeFile, processName) == 0) {
                    dwProcessId = pe32.th32ProcessID;
                    break;
                }
            } while (Process32NextW(hSnap, &pe32));
        }
        CloseHandle(hSnap);
    }
    return dwProcessId;
}

// Performs the actual DLL injection
bool DllHook::LoadLib(DWORD dwProcessId, LPWSTR szDllPath) {
    // 1. Open target process with full access
    HANDLE hProcess = OpenProcess(PROCESS_ALL_ACCESS, FALSE, dwProcessId);
    if (!hProcess) return false;

    // 2. Allocate memory in the target process for the DLL path string
    size_t pathLen = (wcslen(szDllPath) + 1) * sizeof(WCHAR);
    LPVOID pRemoteBuf = VirtualAllocEx(hProcess, NULL, pathLen, MEM_COMMIT, PAGE_READWRITE);
    
    if (pRemoteBuf) {
        // 3. Write the DLL path into the allocated memory
        WriteProcessMemory(hProcess, pRemoteBuf, szDllPath, pathLen, NULL);

        // 4. Create a remote thread that calls LoadLibraryW
        HANDLE hThread = CreateRemoteThread(hProcess, NULL, 0, 
            (LPTHREAD_START_ROUTINE)GetProcAddress(GetModuleHandleW(L"kernel32.dll"), "LoadLibraryW"), 
            pRemoteBuf, 0, NULL);
        
        if (hThread) {
            WaitForSingleObject(hThread, INFINITE);
            CloseHandle(hThread);
        }
    }

    // 5. Cleanup
    VirtualFreeEx(hProcess, pRemoteBuf, 0, MEM_RELEASE);
    CloseHandle(hProcess);
    return true;
}

void DllHook::ShowError(DWORD dwErr, const WCHAR* msg) {
    WCHAR buf[256];
    swprintf_s(buf, L"Error %u: %s", dwErr, msg);
    MessageBoxW(NULL, buf, L"DLL Hook Error", MB_OK | MB_ICONERROR);
}

bool DllHook::FreeLib(DWORD dwProcessId, const WCHAR* szDllPath) {
    // Future implementation for unloading
    return true;
}